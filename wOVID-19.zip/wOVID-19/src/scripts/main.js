import '../scripts/components/navbar.js';
import '../scripts/components/header-content.js';
import '../scripts/components/header-footer.js';
import '../scripts/components/corona-report-item.js';
import '../scripts/components/corona-report-description.js';

const main = () => {
    const baseUrl = 'https://covid19.mathdro.id/api/countries/Indonesia/';

    const getData = () => {
        fetch(baseUrl)
            .then(response => response.json())
            .then(results => {
                const coronaReportItemElement = document.querySelector('corona-report-item');
                coronaReportItemElement.coronaItem = results;
            })
            .catch(error => showMessage());
    }

    const showMessage = (message = 'Periksa koneksi internet...') =>{
        alert(message);
    }

    getData();
}

export default main