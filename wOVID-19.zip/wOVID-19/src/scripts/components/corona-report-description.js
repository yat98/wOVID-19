class CoronaReportDescription extends HTMLElement{
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML = `<h3>Live Report</h3>
                          <p>
                             Jumlah pasien yang terinfeksi covid-19 di negara Indonesia. Update data terakhir 19 Januari 2020
                          </p>`;
    }
}

customElements.define('corona-report-description',CoronaReportDescription);