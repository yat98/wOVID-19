class CoronaReportItem extends HTMLElement{
    constructor(){
        super();
        this.shadowDom = this.attachShadow({mode:'open'});
    }

    set coronaItem(item){
        this._coronaItem = item;
        this.render();
    }

    render(){
        this.shadowDom.innerHTML = '';
        this.shadowDom.innerHTML = `
                                    <style>
                                        *{
                                            padding:0px;
                                            margin:0px;
                                        }
                                        .row{
                                            display:flex;
                                        }
                                        .text-white{
                                            color:white;
                                        }
                                        .align-items-center{
                                            align-items:center;
                                        }     
                                        .bg-dead{
                                            background-color: #F24141;
                                        }

                                        .bg-recovered{
                                            background-color: #49BF5E;
                                        }

                                        .bg-confirmed{
                                            background-color: #F2B035;
                                        }
                                        .flex-basis{
                                            flex-basis: 33.3%;
                                            padding-right:20px
                                        }
                                        .card{
                                            border-radius:10px;
                                            padding:15px 0px;
                                            width:100%;
                                        }
                                        .card-body{
                                            text-align:center;
                                        }
                                        .card-title{
                                            font-size:35px;
                                            font-weight: bold;
                                        }
                                        .card-text{
                                            font-size:16px;
                                            font-weight:regular;
                                        }

                                        @media (max-width:991px){
                                            .flex-basis{
                                                width:100%;
                                                padding:0px;
                                            }
                                            .row{
                                                display:flex;
                                                flex-direction:column;
                                            }
                                            .bg-confirmed{
                                                margin: 25px 0px;
                                            }
                                        }
                                    </style>

                                    <div class="row text-white align-items-center">
                                        <div class="flex-basis">
                                            <div class="card text-center bg-dead">
                                                <div class="card-body">
                                                <h4 class="card-title">${this._coronaItem.deaths.value}</h4>
                                                <p class="card-text">Meninggal</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-basis">
                                            <div class="card text-center bg-confirmed">
                                                <div class="card-body">
                                                <h4 class="card-title">${this._coronaItem.confirmed.value}</h4>
                                                <p class="card-text">Dirawat</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex-basis">
                                            <div class="card text-center bg-recovered">
                                                <div class="card-body">
                                                <h4 class="card-title">${this._coronaItem.recovered.value}</h4>
                                                <p class="card-text">Sembuh</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
    }
}

customElements.define('corona-report-item',CoronaReportItem);