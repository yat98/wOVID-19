import 'regenerator-runtime';
import illustration from './image/illustration.svg';
import "bootstrap/dist/css/bootstrap.min.css";
import './style/style.css';
import main from './scripts/main.js';

main();